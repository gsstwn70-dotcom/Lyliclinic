/**
 * Lily Clinic | Dental Care Citra Palem
 * Master JavaScript File (Clean, Zero Dependencies, Zero Dead Code, Zero console.log)
 */

(function () {
  'use strict';

  var OFFICIAL_WA_SVG = '<svg width="18" height="18" viewBox="0 0 448 512" fill="currentColor" aria-hidden="true">' +
    '<path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path>' +
    '</svg>';

  // ==========================================
  // DATA 12 LAYANAN UTAMA LILY CLINIC
  // ==========================================
  var SERVICES_DATA = {
    'implant-gigi': {
      title: 'Implant Gigi',
      badge: 'Solusi Tanam Gigi Permanen',
      desc: 'Implant gigi adalah prosedur penanaman akar gigi tiruan berbahan titanium medis murni ke dalam tulang rahang untuk menggantikan gigi yang telah hilang. Implant berfungsi dan tampak persis seperti gigi asli, mengembalikan kekuatan kunyah 100% dan mencegah penyusutan tulang rahang.',
      benefits: [
        'Kekuatan kunyah maksimal layaknya gigi asli sendiri tanpa goyang',
        'Mencegah pengeroposan dan penurunan struktur tulang rahang',
        'Tidak merusak atau mengikis gigi sehat di sebelahnya',
        'Daya tahan seumur hidup dengan pemeliharaan dan kebersihan yang baik',
        'Estetika alami yang selaras sempurna dengan senyum Anda'
      ],
      steps: [
        { title: 'Konsultasi & Rontgen 3D', text: 'Pemeriksaan ketebalan tulang rahang dan perencanaan posisi presisi implant.' },
        { title: 'Penanaman Fixture Implant', text: 'Prosedur bedah minor dengan anestesi lokal tanpa rasa nyeri untuk memasang akar titanium.' },
        { title: 'Osseointegrasi', text: 'Masa penyatuan implant dengan tulang rahang secara biologis (2-3 bulan).' },
        { title: 'Pemasangan Crown Permanen', text: 'Pemasangan mahkota keramik zirkonia atau porselen berdaya tahan tinggi.' }
      ],
      estimate: '2 - 3 Kali Kunjungan',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk perawatan Implant Gigi'
    },
    'kawat-gigi-orto': {
      title: 'Kawat Gigi / Orto',
      badge: 'Perapian Posisi & Estetika Gigi',
      desc: 'Perawatan ortodonti profesional untuk memperbaiki susunan gigi yang berjejal, renggang, maju (tonggos), atau gigitan yang tidak pas. Menggunakan pilihan behel metal, sapphire transparan, keramik estetik, hingga clear aligner canggih seperti Invisalign.',
      benefits: [
        'Merapikan susunan gigi untuk senyum simetris dan proporsional',
        'Memperbaiki fungsi gigitan dan artikulasi pengunyahan makanan',
        'Mempermudah pembersihan gigi sehingga mencegah karang dan karies',
        'Meningkatkan profil estetika wajah dan rasa percaya diri',
        'Tersedia opsi behel konvensional, self-ligating, maupun aligner transparan'
      ],
      steps: [
        { title: 'Pencetakan & Foto Diagnostik', text: 'Analisis profil wajah, cetak studi, dan rontgen panoramic/cephalometric.' },
        { title: 'Pemasangan Bracket Orto', text: 'Aplikasi bracket presisi pada setiap gigi dengan lem khusus medis.' },
        { title: 'Kontrol Berkala', text: 'Aktivasi kawat setiap 3-4 minggu untuk menggerakkan gigi ke posisi ideal.' },
        { title: 'Pelepasan & Retainer', text: 'Pemasangan retainer untuk mempertahankan posisi gigi yang sudah rapi sempurna.' }
      ],
      estimate: 'Kontrol rutin per 3-4 minggu',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Kawat Gigi / Orto'
    },
    'veneer': {
      title: 'Veneer',
      badge: 'Transformasi Senyum Putih Berkilau',
      desc: 'Veneer adalah cangkang tipis porselen atau resin komposit yang dilekatkan pada permukaan depan gigi untuk meratakan bentuk, menutup celah, memperbaiki gigi sompel, dan memberikan warna putih alami yang tahan noda seumur hidup.',
      benefits: [
        'Warna putih bersinar alami yang tahan lama dan tidak mudah menguning',
        'Menutup celah antargigi (diastema) tanpa perlu proses kawat gigi lama',
        'Mengoreksi bentuk gigi yang tidak rata, patah, atau runcing',
        'Pengikisan enamel minimal dan aman untuk kesehatan gigi',
        'Desain senyum (Smile Design) yang dipersonalisasi sesuai bentuk wajah'
      ],
      steps: [
        { title: 'Analisis Desain Senyum', text: 'Pemilihan warna dan bentuk gigi yang paling sesuai dengan karakteristik senyum Anda.' },
        { title: 'Preparasi Minimal', text: 'Penyesuaian permukaan enamel gigi sebesar 0.3 - 0.5 mm.' },
        { title: 'Pencetakan Digital / Presisi', text: 'Pembuatan veneer di laboratorium dental berstandar internasional.' },
        { title: 'Bonding Permanen', text: 'Pelekatan veneer menggunakan semen perekat dental berdaya rekat super kuat.' }
      ],
      estimate: '2 Kali Kunjungan (Direct 1 Hari)',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Veneer'
    },
    'operasi-gigi-bungsu': {
      title: 'Operasi Gigi Bungsu',
      badge: 'Odontektomi Aman & Minim Rasa Sakit',
      desc: 'Tindakan pengangkatan gigi geraham ketiga (bungsu) yang tumbuh miring, impaksi (terpendam), terjepit tulang, atau menekan gigi di sebelahnya yang menyebabkan peradangan berulang, bengkak, dan sakit kepala.',
      benefits: [
        'Menghilangkan nyeri berdenyut dan rasa ngilu hebat di rahang belakang',
        'Mencegah kerusakan gigi geraham di sebelahnya akibat karies tersembunyi',
        'Mencegah pembentukan kista rahang dan infeksi jaringan lunak yang meluas',
        'Teknik pembedahan terkini yang minim trauma dengan pemulihan cepat',
        'Didukung anestesi modern sehingga tindakan berlangsung nyaman tanpa rasa sakit'
      ],
      steps: [
        { title: 'Rontgen Panoramic', text: 'Evaluasi letak akar gigi terhadap saluran syaraf rahang bawah.' },
        { title: 'Anestesi Lokal Efektif', text: 'Pemberian bius lokal steril untuk memastikan area rahang kebas total.' },
        { title: 'Tindakan Odontektomi', text: 'Pencabutan gigi bungsu secara hati-hati oleh dokter berpengalaman.' },
        { title: 'Penjahitan & Instruksi Pasca-Bedah', text: 'Penutupan luka dengan jahitan halus dan pemberian obat anti nyeri & bengkak.' }
      ],
      estimate: '1 Kali Tindakan (30 - 45 Menit)',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Operasi Gigi Bungsu'
    },
    'tambalan-estetik': {
      title: 'Tambalan Estetik',
      badge: 'Restorasi Komposit Sewarna Gigi Asli',
      desc: 'Penanganan gigi berlubang menggunakan bahan komposit resin nanoteknologi modern yang disesuaikan secara presisi dengan warna enamel gigi asli. Tambalan merekat kuat, tidak terlihat dari luar, dan mengembalikan fungsi kunyah secara sempurna.',
      benefits: [
        'Warna tambalan menyatu sempurna dengan gigi asli tanpa batas terlihat',
        'Bahan komposit nano berkekuatan tinggi tahan terhadap tekanan kunyah',
        'Mencegah karies meluas hingga ke saraf gigi yang menimbulkan sakit parah',
        'Proses pengerjaan cepat dan dapat langsung dipakai makan',
        'Bebas merkuri (Mercury-Free) dan 100% aman bagi kesehatan tubuh'
      ],
      steps: [
        { title: 'Pembersihan Jaringan Karies', text: 'Mengangkat seluruh bagian gigi yang busuk atau berlubang secara steril.' },
        { title: 'Aplikasi Etching & Bonding', text: 'Pelapisan agen perekat mikroskopis untuk memastikan tambalan tidak mudah lepas.' },
        { title: 'Layering Komposit & Curing', text: 'Penataan komposit selapis demi selapis lalu dikeraskan dengan sinar laser biru.' },
        { title: 'Polishing & Penyesuaian Gigitan', text: 'Penghalusan permukaan dan pengecekan gigitan agar nyaman maksimal.' }
      ],
      estimate: '1 Kali Kunjungan (30 Menit)',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Tambalan Estetik'
    },
    'gigi-palsu': {
      title: 'Gigi Palsu',
      badge: 'Gigi Tiruan Lepasan Presisi & Nyaman',
      desc: 'Pembuatan gigi tiruan lepasan baik sebagian maupun lengkap untuk mengembalikan kemampuan mengunyah makanan, berbicara dengan jelas, serta menopang otot wajah agar tidak tampak kempot atau menua sebelum waktunya.',
      benefits: [
        'Mengembalikan fungsi mengunyah berbagai variasi makanan dengan lezat',
        'Menopang bentuk bibir dan pipi agar wajah tampak lebih segar dan awet muda',
        'Membantu artikulasi bicara agar pelafalan kata lebih jelas',
        'Tersedia pilihan bahan akrilik konvensional, valplast lentur tanpa kawat, dan kerangka logam',
        'Dibuat sesuai anatomi rongga mulut pasien sehingga pas dan tidak mudah longgar'
      ],
      steps: [
        { title: 'Pencetakan Rongga Mulut', text: 'Mencetak kontur gusi dan gigi yang tersisa secara akurat.' },
        { title: 'Penentuan Gigitan & Warna', text: 'Menyesuaikan ketinggian gigitan dan warna gigi tiruan yang paling natural.' },
        { title: 'Uji Coba Wax (Bite Try-In)', text: 'Memastikan kenyamanan dan estetika sebelum proses pabrikasi akhir.' },
        { title: 'Insersi & Edukasi Perawatan', text: 'Pemasangan gigi palsu jadi serta panduan cara melepas dan merawat.' }
      ],
      estimate: '3 - 4 Kali Kunjungan',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Gigi Palsu'
    },
    'crown-and-bridge': {
      title: 'Crown and Bridge',
      badge: 'Mahkota & Jembatan Gigi Permanen',
      desc: 'Solusi restorasi tetap untuk melindungi gigi yang rapuh pasca-perawatan saraf, gigi patah besar, atau menggantikan satu/beberapa gigi yang hilang dengan menyambungkannya pada gigi penyangga di sampingnya.',
      benefits: [
        'Melindungi gigi yang rapuh agar tidak pecah saat digunakan mengunyah',
        'Menggantikan gigi hilang secara permanen tanpa perlu dilepas pasang',
        'Bahan porcelain-fused-to-metal (PFM) atau All-Ceramic Zirconia super kokoh',
        'Estetika kilau dan pantulan cahaya yang sangat menyerupai gigi asli',
        'Memperbaiki bentuk dan ukuran gigi yang aus atau cacat struktural'
      ],
      steps: [
        { title: 'Preparasi Gigi Penyangga', text: 'Membentuk mahkota gigi yang akan dipasangi crown.' },
        { title: 'Cetak Presisi & Crown Sementara', text: 'Pencetakan detail serta pemasangan crown sementara untuk kenyamanan.' },
        { title: 'Fabrikasi Laboratorium', text: 'Pembuatan mahkota menggunakan teknologi CAD/CAM tingkat kepresisian mikron.' },
        { title: 'Sementasi Permanen', text: 'Pelekatan crown permanen menggunakan semen medis tahan air.' }
      ],
      estimate: '2 Kali Kunjungan',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Crown and Bridge'
    },
    'perawatan-gusi': {
      title: 'Perawatan Gusi',
      badge: 'Periodontik & Kesehatan Jaringan Penyangga',
      desc: 'Perawatan kesehatan jaringan pendukung gigi meliputi kuretase gusi, root planing, dan terapi periodontik mendalam untuk mengatasi gusi berdarah, bengkak, bau mulut menahun, serta gusi turun akibat infeksi.',
      benefits: [
        'Menghentikan gusi berdarah saat menyikat gigi atau mengunyah',
        'Mengatasi pembengkakan dan peradangan pada poket gusi',
        'Menghilangkan aroma bau mulut (halitosis) tak sedap secara tuntas',
        'Mencegah kegoyangan gigi akibat penurunan tulang penyangga gusi',
        'Memulihkan pelekatan jaringan gusi sehat secara menyeluruh'
      ],
      steps: [
        { title: 'Pemeriksaan Kedalaman Poket Gusi', text: 'Pengecekan area peradangan dan akumulasi bakteri subgingiva.' },
        { title: 'Pembersihan Mendalam', text: 'Pengangkatan plak, kalkulus, dan jaringan granulasi meradang secara steril.' },
        { title: 'Root Planing (Bila Perlu)', text: 'Penghalusan permukaan akar gigi agar gusi dapat melekat kembali dengan kuat.' },
        { title: 'Terapi & Kontrol Penyembuhan', text: 'Pemberian obat periodontal dan evaluasi regenerasi jaringan gusi.' }
      ],
      estimate: '1 - 2 Kali Kunjungan',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Perawatan Gusi'
    },
    'scaling-polishing': {
      title: 'Scaling & Polishing',
      badge: 'Pembersihan Karang Gigi Ultrasonik & Poles',
      desc: 'Pembersihan karang gigi (plak dan tartar) secara menyeluruh menggunakan alat ultrasonik modern bergetar halus yang tidak mengikis enamel gigi, dilanjutkan polishing pasta khusus agar gigi bersih berkilau dan napas kembali segar.',
      benefits: [
        'Membersihkan karang gigi membandel di sela-sela dan garis gusi secara tuntas',
        'Menghilangkan noda permukaan akibat kopi, teh, atau kebiasaan merokok',
        'Mencegah gusi berdarah, radang gusi (gingivitis), dan gigi goyang',
        'Membuat napas lebih segar dan mulut terasa bersih ringan seketika',
        'Prosedur nyaman dengan getaran ultrasonik halus dan minim ngilu'
      ],
      steps: [
        { title: 'Pemeriksaan Kamera Intraoral', text: 'Menunjukkan area penumpukan karang dan noda pada layar monitor secara transparan.' },
        { title: 'Ultrasonic Scaling', text: 'Getaran frekuensi tinggi bersama semprotan air steril meluruhkan karang tanpa merusak enamel.' },
        { title: 'Stain & Plaque Polishing', text: 'Pemolesan dengan pasta profilaksis lembut agar permukaan gigi licin sempurna.' },
        { title: 'Edukasi & Jadwal Rutin', text: 'Panduan penyikatan optimal untuk perawatan berkala setiap 6 bulan.' }
      ],
      estimate: '1 Kali Kunjungan (30 - 45 Menit)',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan jadwal untuk Scaling & Polishing'
    },
    'bleaching-pemutihan-gigi': {
      title: 'Bleaching / Pemutihan Gigi',
      badge: 'Pencerahan Warna Gigi Aman & Instan',
      desc: 'Perawatan pemutihan gigi profesional di klinik (in-office whitening) menggunakan gel pemutih medis berstandar aman dan penyinaran khusus untuk mencerahkan warna gigi beberapa tingkat lebih putih hanya dalam satu kali kunjungan.',
      benefits: [
        'Warna gigi tampak lebih putih cerah alami dalam waktu singkat',
        'Mengatasi gigi kusam dan menguning akibat kopi, teh, atau faktor usia',
        'Prosedur diawasi langsung dokter gigi dengan pelindung gusi khusus',
        'Gel berbahan desensitizing untuk meminimalkan rasa ngilu pasca-tindakan',
        'Hasil merata alami tanpa merusak struktur lapisan enamel gigi'
      ],
      steps: [
        { title: 'Pembersihan & Shade Check', text: 'Pencocokan warna gigi awal dan pembersihan plak permukaan agar gel meresap optimal.' },
        { title: 'Aplikasi Pelindung Gusi', text: 'Melapisi jaringan lunak gusi secara rapat demi keamanan dan kenyamanan penuh.' },
        { title: 'Gel Whitening & Aktivasi Sinar', text: 'Aplikasi gel pemutih medis profesional dan aktivasi sinar lembut selama beberapa siklus.' },
        { title: 'Desensitizing & Evaluasi Warna', text: 'Aplikasi gel penenang enamel serta perbandingan langsung warna gigi sebelum-sesudah.' }
      ],
      estimate: '1 Kali Kunjungan (60 Menit)',
      waMessage: 'Halo Lily Clinic, saya mau tanya harga dan konsultasi untuk Bleaching / Pemutihan Gigi'
    },
    'perawatan-gigi-anak': {
      title: 'Perawatan Gigi Anak',
      badge: 'Pedodonti Ramah Anak & Bebas Trauma',
      desc: 'Pelayanan kesehatan gigi khusus anak-anak dengan pendekatan psikologis yang sabar, ceria, dan bersahabat. Meliputi penambalan gigi susu, cabut gigi susu goyang, aplikasi fluoride pencegah karies, hingga penambalan celah gigi (fissure sealant).',
      benefits: [
        'Pendekatan dokter dan perawat yang sangat sabar, ramah, dan komunikatif',
        'Menciptakan pengalaman ke dokter gigi yang menyenangkan tanpa rasa takut',
        'Menjaga gigi susu tetap sehat sebagai penuntun tumbuhnya gigi permanen',
        'Mencegah infeksi dan sakit gigi yang mengganggu nafsu makan serta tidur anak',
        'Edukasi cara menyikat gigi yang asyik bagi anak dan orang tua'
      ],
      steps: [
        { title: 'Pendekatan Akrab (Tell-Show-Do)', text: 'Mengenalkan alat-alat dokter gigi kepada si kecil dengan bahasa santai dan ceria.' },
        { title: 'Pemeriksaan Menyeluruh', text: 'Pengecekan gigi berlubang, posisi gigitan, dan kebersihan mulut anak.' },
        { title: 'Tindakan Lembut & Cepat', text: 'Perawatan tambalan atau pencabutan dengan teknik minim trauma.' },
        { title: 'Reward & Apresiasi', text: 'Pemberian apresiasi atas keberanian si kecil agar selalu semangat menjaga gigi.' }
      ],
      estimate: '1 Kali Kunjungan (30 Menit)',
      waMessage: 'Halo Lily Clinic, saya mau tanya jadwal dan konsultasi untuk Perawatan Gigi Anak'
    },
    'konsultasi-dokter-umum': {
      title: 'Konsultasi Dokter Umum',
      badge: 'Pemeriksaan Kesehatan Keluarga Terpadu',
      desc: 'Layanan klinik pratama dokter umum bersama Dr. Dwi Aprilita untuk pemeriksaan kesehatan harian keluarga, keluhan demam, batuk pilek, gangguan pencernaan, pemeriksaan tekanan darah, hingga surat keterangan sehat dan konsultasi pra-tindakan medis.',
      benefits: [
        'Pemeriksaan menyeluruh dengan dokter umum yang teliti, hangat, dan komunikatif',
        'Satu lokasi terpadu untuk kebutuhan kesehatan gigi maupun kesehatan umum keluarga',
        'Penjelasan diagnosis serta resep pengobatan yang jelas dan sesuai kebutuhan',
        'Mendukung skrining kondisi medis umum (hipertensi/diabetes) sebelum tindakan gigi tertentu',
        'Ruang konsultasi bersih, nyaman, dan mudah dijangkau di Citra Garden 2 Ext'
      ],
      steps: [
        { title: 'Registrasi & Pengukuran Tanda Vital', text: 'Pengecekan suhu tubuh, tekanan darah, dan keluhan utama pasien.' },
        { title: 'Anamnesis & Pemeriksaan Fisik', text: 'Wawancara medis mendalam dan pemeriksaan fisik oleh Dr. Dwi Aprilita.' },
        { title: 'Penjelasan Kondisi & Terapi', text: 'Edukasi jelas mengenai kondisi kesehatan serta rencana pengobatan.' },
        { title: 'Resep Obat & Tindak Lanjut', text: 'Pemberian resep terarah dan saran pemulihan di rumah.' }
      ],
      estimate: '1 Kali Kunjungan (20 - 30 Menit)',
      waMessage: 'Halo Lily Clinic, saya mau tanya jadwal dan konsultasi Dokter Umum bersama Dr. Dwi Aprilita'
    }
  };

  var LEGACY_SLUG_ALIAS = {
    'pencabutan-gigi': 'operasi-gigi-bungsu',
    'perawatan-syaraf-gigi': 'tambalan-estetik'
  };

  // ==========================================
  // 1. NAVBAR MOBILE DRAWER & ACTIVE LINK
  // ==========================================
  function initNavbar() {
    var toggleBtn = document.querySelector('.nav-toggle');
    var mobileNav = document.querySelector('.mobile-nav');

    if (toggleBtn && mobileNav) {
      toggleBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var isOpen = mobileNav.classList.contains('open');
        mobileNav.classList.toggle('open', !isOpen);
        toggleBtn.classList.toggle('open', !isOpen);
      });

      var mobileLinks = mobileNav.querySelectorAll('a');
      for (var i = 0; i < mobileLinks.length; i++) {
        mobileLinks[i].addEventListener('click', function () {
          mobileNav.classList.remove('open');
          toggleBtn.classList.remove('open');
        });
      }

      document.addEventListener('click', function (e) {
        if (mobileNav.classList.contains('open') && !mobileNav.contains(e.target) && !toggleBtn.contains(e.target)) {
          mobileNav.classList.remove('open');
          toggleBtn.classList.remove('open');
        }
      });
    }

    var currentPath = window.location.pathname;
    var filename = currentPath.substring(currentPath.lastIndexOf('/') + 1) || 'index.html';
    var allNavLinks = document.querySelectorAll('.nav-links a, .mobile-nav-links a');

    for (var j = 0; j < allNavLinks.length; j++) {
      var href = allNavLinks[j].getAttribute('href');
      if (href) {
        var cleanHref = href.split('#')[0].split('?')[0];
        if (cleanHref === filename || (filename === 'index.html' && cleanHref === '/')) {
          allNavLinks[j].classList.add('active');
        }
      }
    }
  }

  // ==========================================
  // 2. HERO SLIDER (SWIPE, DRAG & DOTS)
  // ==========================================
  function initHeroSlider() {
    var heroSection = document.querySelector('.hero-arch-wrapper');
    var track = document.querySelector('.hero-arch-track');
    var slides = document.querySelectorAll('.hero-arch-slide');
    var dots = document.querySelectorAll('.hero-arch-dot');

    if (!track || slides.length === 0 || !heroSection) return;

    var currentIndex = 0;
    var totalSlides = slides.length;
    var autoSlideInterval = null;
    var resumeTimeout = null;
    var autoSlideDelay = 5000;

    var isDragging = false;
    var startX = 0;
    var diffX = 0;
    var dragThreshold = 50;

    function updateSlider(animate) {
      track.classList.toggle('dragging', animate === false);
      track.style.transform = 'translateX(' + (-currentIndex * 100) + '%)';
      for (var i = 0; i < dots.length; i++) {
        dots[i].classList.toggle('active', i === currentIndex);
      }
    }

    function goToSlide(index) {
      if (index < 0) {
        currentIndex = totalSlides - 1;
      } else if (index >= totalSlides) {
        currentIndex = 0;
      } else {
        currentIndex = index;
      }
      updateSlider(true);
    }

    function stopAutoSlide() {
      if (autoSlideInterval) {
        clearInterval(autoSlideInterval);
        autoSlideInterval = null;
      }
    }

    function startAutoSlide() {
      stopAutoSlide();
      autoSlideInterval = setInterval(function () {
        goToSlide(currentIndex + 1);
      }, autoSlideDelay);
    }

    function scheduleResumeAutoSlide() {
      stopAutoSlide();
      if (resumeTimeout) clearTimeout(resumeTimeout);
      resumeTimeout = setTimeout(startAutoSlide, autoSlideDelay);
    }

    for (var d = 0; d < dots.length; d++) {
      (function (index) {
        dots[index].addEventListener('click', function (e) {
          e.preventDefault();
          goToSlide(index);
          scheduleResumeAutoSlide();
        });
      })(d);
    }

    heroSection.addEventListener('touchstart', function (e) {
      if (e.touches.length !== 1) return;
      stopAutoSlide();
      isDragging = true;
      startX = e.touches[0].clientX;
      diffX = 0;
      track.classList.add('dragging');
    }, { passive: true });

    heroSection.addEventListener('touchmove', function (e) {
      if (!isDragging) return;
      diffX = e.touches[0].clientX - startX;
      var trackWidth = heroSection.offsetWidth || 1;
      var offsetPercent = ((-currentIndex * trackWidth + diffX) / trackWidth) * 100;
      track.style.transform = 'translateX(' + offsetPercent + '%)';
    }, { passive: true });

    heroSection.addEventListener('touchend', function () {
      if (!isDragging) return;
      isDragging = false;
      track.classList.remove('dragging');
      if (diffX < -dragThreshold) goToSlide(currentIndex + 1);
      else if (diffX > dragThreshold) goToSlide(currentIndex - 1);
      else updateSlider(true);
      scheduleResumeAutoSlide();
    });

    heroSection.addEventListener('mousedown', function (e) {
      if (e.target.closest('button') || e.target.closest('a')) return;
      stopAutoSlide();
      isDragging = true;
      startX = e.clientX;
      diffX = 0;
      track.classList.add('dragging');
      e.preventDefault();
    });

    window.addEventListener('mousemove', function (e) {
      if (!isDragging) return;
      diffX = e.clientX - startX;
      var trackWidth = heroSection.offsetWidth || 1;
      var offsetPercent = ((-currentIndex * trackWidth + diffX) / trackWidth) * 100;
      track.style.transform = 'translateX(' + offsetPercent + '%)';
    });

    window.addEventListener('mouseup', function () {
      if (!isDragging) return;
      isDragging = false;
      track.classList.remove('dragging');
      if (diffX < -dragThreshold) goToSlide(currentIndex + 1);
      else if (diffX > dragThreshold) goToSlide(currentIndex - 1);
      else updateSlider(true);
      scheduleResumeAutoSlide();
    });

    startAutoSlide();
  }

  // ==========================================
  // 3. FAQ ACCORDION (faq.html)
  // ==========================================
  function initFaqAccordion() {
    var faqItems = document.querySelectorAll('.faq-item');
    if (faqItems.length === 0) return;

    for (var i = 0; i < faqItems.length; i++) {
      var item = faqItems[i];
      var initAns = item.querySelector('.faq-answer');
      if (item.classList.contains('active') && initAns) {
        initAns.style.maxHeight = (initAns.scrollHeight + 48) + 'px';
      }
      var questionBtn = item.querySelector('.faq-question');
      if (questionBtn) {
        questionBtn.addEventListener('click', function () {
          var parent = this.closest('.faq-item');
          var answer = parent.querySelector('.faq-answer');
          var isActive = parent.classList.contains('active');

          for (var j = 0; j < faqItems.length; j++) {
            var otherItem = faqItems[j];
            if (otherItem !== parent) {
              otherItem.classList.remove('active');
              var otherAns = otherItem.querySelector('.faq-answer');
              if (otherAns) otherAns.style.maxHeight = '0px';
              var otherQ = otherItem.querySelector('.faq-question');
              if (otherQ) otherQ.setAttribute('aria-expanded', 'false');
            }
          }

          if (isActive) {
            parent.classList.remove('active');
            answer.style.maxHeight = '0px';
            this.setAttribute('aria-expanded', 'false');
          } else {
            parent.classList.add('active');
            answer.style.maxHeight = (answer.scrollHeight + 48) + 'px';
            this.setAttribute('aria-expanded', 'true');
          }
        });
      }
    }
  }

  // ==========================================
  // 4. LAYANAN DETAIL LOADER (layanan-detail.html)
  // ==========================================
  function initLayananDetail() {
    var container = document.getElementById('layanan-detail-container');
    if (!container) return;

    var urlParams = new URLSearchParams(window.location.search);
    var slug = urlParams.get('layanan');
    if (slug && LEGACY_SLUG_ALIAS[slug]) {
      slug = LEGACY_SLUG_ALIAS[slug];
    }
    var service = slug && SERVICES_DATA[slug];
    if (!service) {
      slug = 'implant-gigi';
      service = SERVICES_DATA[slug];
    }

    document.title = service.title + ' - Lily Clinic Dental Care Citra Palem';

    var breadcrumbEl = document.getElementById('detail-breadcrumb-current');
    if (breadcrumbEl) breadcrumbEl.textContent = service.title;

    var badgeEl = document.getElementById('detail-badge');
    if (badgeEl) badgeEl.textContent = service.badge;

    var titleEl = document.getElementById('detail-title');
    if (titleEl) titleEl.textContent = service.title;

    var descEl = document.getElementById('detail-desc');
    if (descEl) descEl.textContent = service.desc;

    var benefitsListEl = document.getElementById('detail-benefits');
    if (benefitsListEl) {
      benefitsListEl.innerHTML = '';
      for (var b = 0; b < service.benefits.length; b++) {
        var li = document.createElement('li');
        li.className = 'benefit-item';
        li.innerHTML = '<span class="benefit-icon">' +
          '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">' +
          '<polyline points="20 6 9 17 4 12"></polyline></svg>' +
          '</span>' +
          '<span>' + service.benefits[b] + '</span>';
        benefitsListEl.appendChild(li);
      }
    }

    var stepsListEl = document.getElementById('detail-steps');
    if (stepsListEl) {
      stepsListEl.innerHTML = '';
      for (var s = 0; s < service.steps.length; s++) {
        var step = service.steps[s];
        var stepDiv = document.createElement('div');
        stepDiv.className = 'step-flow-item';
        stepDiv.innerHTML = '<div class="step-flow-num">' + (s + 1) + '</div>' +
          '<div class="step-flow-content">' +
          '<h4>' + step.title + '</h4>' +
          '<p>' + step.text + '</p>' +
          '</div>';
        stepsListEl.appendChild(stepDiv);
      }
    }

    var estEl = document.getElementById('detail-estimate');
    if (estEl) estEl.textContent = service.estimate;

    var bookingBtn = document.getElementById('detail-btn-booking');
    if (bookingBtn) {
      bookingBtn.setAttribute('href', 'booking.html?layanan=' + encodeURIComponent(slug));
    }

    var waBtn = document.getElementById('detail-btn-wa');
    if (waBtn) {
      waBtn.setAttribute('href', 'https://wa.me/628886161770?text=' + encodeURIComponent(service.waMessage));
    }

    var otherServicesList = document.getElementById('detail-other-services');
    if (otherServicesList) {
      otherServicesList.innerHTML = '';
      var keys = Object.keys(SERVICES_DATA);
      for (var k = 0; k < keys.length; k++) {
        var otherKey = keys[k];
        var a = document.createElement('a');
        a.href = 'layanan-detail.html?layanan=' + encodeURIComponent(otherKey);
        a.className = 'sidebar-service-link' + (otherKey === slug ? ' active' : '');
        a.textContent = SERVICES_DATA[otherKey].title;
        otherServicesList.appendChild(a);
      }
    }
  }

  // ==========================================
  // 5. BOOKING MODAL GLOBAL & HALAMAN BOOKING
  // ==========================================
  var BOOKING_SERVICES = [
    'Implant Gigi',
    'Kawat Gigi / Orto',
    'Veneer',
    'Operasi Gigi Bungsu',
    'Tambalan Estetik',
    'Gigi Palsu',
    'Crown and Bridge',
    'Perawatan Gusi',
    'Scaling & Polishing',
    'Bleaching / Pemutihan Gigi',
    'Perawatan Gigi Anak',
    'Konsultasi Dokter Umum',
    'Lainnya / Konsultasi Dulu'
  ];

  var BOOKING_DOCTORS = [
    {
      value: 'Dokter Jaga / Siapa Saja Yang Bertugas (rekomendasi, paling cepat)',
      label: 'Dokter Jaga / Siapa Saja Yang Bertugas (rekomendasi, paling cepat)',
      hint: ''
    },
    {
      value: 'drg. Lily Widjaja, MSc. FICD. FISID - Dokter Gigi (Senin 09.30 - 12.00, By Appointment di luar jam praktek)',
      label: 'drg. Lily Widjaja, MSc. FICD. FISID - Dokter Gigi (Senin 09.30 - 12.00, By Appointment di luar jam praktek)',
      hint: 'drg. Lily Widjaja praktek Senin 09.30 - 12.00 (juga tersedia By Appointment di luar jam praktek)'
    },
    {
      value: 'drg. E. Widojati - Dokter Gigi (Senin 10.00 - 15.00)',
      label: 'drg. E. Widojati - Dokter Gigi (Senin 10.00 - 15.00)',
      hint: 'drg. E. Widojati praktek Senin 10.00 - 15.00'
    },
    {
      value: 'drg. Mariska Slametiani - Dokter Gigi (Senin 17.00 - 20.00)',
      label: 'drg. Mariska Slametiani - Dokter Gigi (Senin 17.00 - 20.00)',
      hint: 'drg. Mariska Slametiani praktek Senin 17.00 - 20.00'
    },
    {
      value: 'Dr. Dwi Aprilita - Dokter Umum (Senin 15.00 - 18.00)',
      label: 'Dr. Dwi Aprilita - Dokter Umum (Senin 15.00 - 18.00)',
      hint: 'Dr. Dwi Aprilita praktek Senin 15.00 - 18.00'
    }
  ];

  var BOOKING_TIMES = ['09.00', '10.00', '11.00', '13.00', '14.00', '15.00', '16.00', '17.00', '18.00', '19.00', '20.00'];

  function mapServiceToDropdownValue(rawSlugOrName) {
    if (!rawSlugOrName) return '';
    var key = rawSlugOrName.trim().toLowerCase();
    var map = {
      'implant-gigi': 'Implant Gigi',
      'kawat-gigi-orto': 'Kawat Gigi / Orto',
      'veneer': 'Veneer',
      'veneer gigi': 'Veneer',
      'operasi-gigi-bungsu': 'Operasi Gigi Bungsu',
      'pencabutan-gigi': 'Operasi Gigi Bungsu',
      'tambalan-estetik': 'Tambalan Estetik',
      'gigi-palsu': 'Gigi Palsu',
      'crown-and-bridge': 'Crown and Bridge',
      'perawatan-gusi': 'Perawatan Gusi',
      'scaling-polishing': 'Scaling & Polishing',
      'scaling': 'Scaling & Polishing',
      'bleaching-pemutihan-gigi': 'Bleaching / Pemutihan Gigi',
      'bleaching': 'Bleaching / Pemutihan Gigi',
      'perawatan-gigi-anak': 'Perawatan Gigi Anak',
      'konsultasi-dokter-umum': 'Konsultasi Dokter Umum',
      'dokter umum': 'Konsultasi Dokter Umum',
      'perawatan-syaraf-gigi': 'Lainnya / Konsultasi Dulu'
    };
    if (map[key]) return map[key];
    for (var i = 0; i < BOOKING_SERVICES.length; i++) {
      if (BOOKING_SERVICES[i].toLowerCase() === key) return BOOKING_SERVICES[i];
    }
    return '';
  }

  function mapDoctorToDropdownValue(rawDoctor) {
    if (!rawDoctor) return '';
    var needle = rawDoctor.trim().toLowerCase();
    for (var i = 0; i < BOOKING_DOCTORS.length; i++) {
      if (BOOKING_DOCTORS[i].value.toLowerCase().indexOf(needle) !== -1) {
        return BOOKING_DOCTORS[i].value;
      }
    }
    return '';
  }

  function getTodayDateString() {
    var d = new Date();
    var yyyy = d.getFullYear();
    var mm = String(d.getMonth() + 1);
    if (mm.length < 2) mm = '0' + mm;
    var dd = String(d.getDate());
    if (dd.length < 2) dd = '0' + dd;
    return yyyy + '-' + mm + '-' + dd;
  }

  function updateDoctorScheduleHint(doctorVal, hintEl) {
    if (!hintEl) return;
    var matchedHint = '';
    for (var i = 0; i < BOOKING_DOCTORS.length; i++) {
      if (BOOKING_DOCTORS[i].value === doctorVal) {
        matchedHint = BOOKING_DOCTORS[i].hint;
        break;
      }
    }
    if (matchedHint) {
      hintEl.textContent = 'Info Jadwal: ' + matchedHint;
      hintEl.classList.add('show');
    } else {
      hintEl.textContent = '';
      hintEl.classList.remove('show');
    }
  }

  function validateFieldError(inputEl, errorEl, message) {
    if (!inputEl || !errorEl) return;
    if (message) {
      inputEl.classList.add('has-error');
      errorEl.textContent = message;
      errorEl.classList.add('show');
    } else {
      inputEl.classList.remove('has-error');
      errorEl.textContent = '';
      errorEl.classList.remove('show');
    }
  }

  function setupBookingFormInstance(prefix, opts) {
    var form = document.getElementById(prefix + '-form');
    if (!form) return null;

    var nameInput = document.getElementById(prefix + '-name');
    var phoneInput = document.getElementById(prefix + '-phone');
    var serviceSelect = document.getElementById(prefix + '-service');
    var doctorSelect = document.getElementById(prefix + '-doctor');
    var dateInput = document.getElementById(prefix + '-date');
    var timeSelect = document.getElementById(prefix + '-time');
    var notesInput = document.getElementById(prefix + '-notes');
    var timeHintEl = document.getElementById(prefix + '-doctor-time-hint');
    var successBox = document.getElementById(prefix + '-success-box');

    var todayStr = getTodayDateString();
    if (dateInput) {
      dateInput.setAttribute('min', todayStr);
      if (!dateInput.value) dateInput.value = todayStr;
    }

    if (doctorSelect && timeHintEl) {
      doctorSelect.addEventListener('change', function () {
        updateDoctorScheduleHint(doctorSelect.value, timeHintEl);
        validateFieldError(doctorSelect, document.getElementById(prefix + '-doctor-error'), '');
      });
    }

    var liveFields = [
      { input: nameInput, errId: prefix + '-name-error' },
      { input: phoneInput, errId: prefix + '-phone-error' },
      { input: serviceSelect, errId: prefix + '-service-error' },
      { input: dateInput, errId: prefix + '-date-error' },
      { input: timeSelect, errId: prefix + '-time-error' }
    ];

    for (var f = 0; f < liveFields.length; f++) {
      (function (item) {
        if (!item.input) return;
        var evt = item.input.tagName === 'SELECT' || item.input.type === 'date' ? 'change' : 'input';
        item.input.addEventListener(evt, function () {
          validateFieldError(item.input, document.getElementById(item.errId), '');
        });
      })(liveFields[f]);
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var valid = true;
      var firstInvalid = null;

      var nameVal = nameInput ? nameInput.value.trim() : '';
      var phoneVal = phoneInput ? phoneInput.value.trim() : '';
      var phoneDigits = phoneVal.replace(/\D/g, '');
      var serviceVal = serviceSelect ? serviceSelect.value : '';
      var doctorVal = doctorSelect ? doctorSelect.value : '';
      var dateVal = dateInput ? dateInput.value : '';
      var timeVal = timeSelect ? timeSelect.value : '';
      var notesVal = notesInput && notesInput.value.trim() ? notesInput.value.trim() : '-';

      if (!nameVal) {
        validateFieldError(nameInput, document.getElementById(prefix + '-name-error'), 'Nama lengkap pasien wajib diisi.');
        valid = false;
        firstInvalid = firstInvalid || nameInput;
      } else {
        validateFieldError(nameInput, document.getElementById(prefix + '-name-error'), '');
      }

      if (!phoneVal) {
        validateFieldError(phoneInput, document.getElementById(prefix + '-phone-error'), 'Nomor WhatsApp pasien wajib diisi.');
        valid = false;
        firstInvalid = firstInvalid || phoneInput;
      } else if (/[a-zA-Z]/.test(phoneVal) || phoneDigits.length < 10) {
        validateFieldError(phoneInput, document.getElementById(prefix + '-phone-error'), 'Nomor WhatsApp harus berupa angka, minimal 10 digit.');
        valid = false;
        firstInvalid = firstInvalid || phoneInput;
      } else {
        validateFieldError(phoneInput, document.getElementById(prefix + '-phone-error'), '');
      }

      if (!serviceVal) {
        validateFieldError(serviceSelect, document.getElementById(prefix + '-service-error'), 'Silakan pilih layanan terlebih dahulu.');
        valid = false;
        firstInvalid = firstInvalid || serviceSelect;
      } else {
        validateFieldError(serviceSelect, document.getElementById(prefix + '-service-error'), '');
      }

      if (!doctorVal) {
        validateFieldError(doctorSelect, document.getElementById(prefix + '-doctor-error'), 'Silakan pilih dokter.');
        valid = false;
        firstInvalid = firstInvalid || doctorSelect;
      } else {
        validateFieldError(doctorSelect, document.getElementById(prefix + '-doctor-error'), '');
      }

      if (!dateVal) {
        validateFieldError(dateInput, document.getElementById(prefix + '-date-error'), 'Tanggal kunjungan wajib dipilih.');
        valid = false;
        firstInvalid = firstInvalid || dateInput;
      } else if (dateVal < todayStr) {
        validateFieldError(dateInput, document.getElementById(prefix + '-date-error'), 'Tanggal tidak boleh sebelum hari ini.');
        valid = false;
        firstInvalid = firstInvalid || dateInput;
      } else {
        validateFieldError(dateInput, document.getElementById(prefix + '-date-error'), '');
      }

      if (!timeVal) {
        validateFieldError(timeSelect, document.getElementById(prefix + '-time-error'), 'Jam kunjungan wajib dipilih.');
        valid = false;
        firstInvalid = firstInvalid || timeSelect;
      } else {
        validateFieldError(timeSelect, document.getElementById(prefix + '-time-error'), '');
      }

      if (!valid) {
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      var waText = 'Halo Lily Clinic, saya mau Booking Janji Temu \uD83D\uDE4F\n' +
        'Nama: ' + nameVal + '\n' +
        'No WA: ' + phoneVal + '\n' +
        'Layanan: ' + serviceVal + '\n' +
        'Dokter: ' + doctorVal + '\n' +
        'Tanggal: ' + dateVal + '\n' +
        'Jam: ' + timeVal + '\n' +
        'Keluhan: ' + notesVal;

      var waLink = 'https://wa.me/628886161770?text=' + encodeURIComponent(waText);
      window.open(waLink, '_blank', 'noopener,noreferrer');

      if (successBox) successBox.classList.add('show');
      if (opts && typeof opts.onSuccess === 'function') opts.onSuccess();
    });

    return {
      prefill: function (serviceSlugOrName, doctorName) {
        if (successBox) successBox.classList.remove('show');
        if (serviceSelect) {
          serviceSelect.value = mapServiceToDropdownValue(serviceSlugOrName) || '';
        }
        if (doctorSelect) {
          var mappedDoc = mapDoctorToDropdownValue(doctorName);
          if (mappedDoc) doctorSelect.value = mappedDoc;
          else doctorSelect.selectedIndex = 0;
          updateDoctorScheduleHint(doctorSelect.value, timeHintEl);
        }
        if (dateInput) {
          dateInput.setAttribute('min', getTodayDateString());
          if (!dateInput.value || dateInput.value < getTodayDateString()) {
            dateInput.value = getTodayDateString();
          }
        }
        for (var c = 0; c < liveFields.length; c++) {
          if (liveFields[c].input) {
            validateFieldError(liveFields[c].input, document.getElementById(liveFields[c].errId), '');
          }
        }
      }
    };
  }

  function buildBookingSelectOptions(arr, isDoctor) {
    var html = '';
    for (var i = 0; i < arr.length; i++) {
      if (isDoctor) {
        html += '<option value="' + arr[i].value + '">' + arr[i].label + '</option>';
      } else {
        html += '<option value="' + arr[i] + '">' + arr[i] + '</option>';
      }
    }
    return html;
  }

  function initGlobalBookingModal() {
    if (!document.getElementById('global-booking-modal')) {
      var modalBackdrop = document.createElement('div');
      modalBackdrop.className = 'booking-modal-backdrop';
      modalBackdrop.id = 'global-booking-modal';
      modalBackdrop.setAttribute('role', 'dialog');
      modalBackdrop.setAttribute('aria-modal', 'true');
      modalBackdrop.setAttribute('aria-labelledby', 'global-booking-modal-title');

      var serviceOptsHtml = '<option value="" disabled selected>-- Pilih Layanan --</option>' + buildBookingSelectOptions(BOOKING_SERVICES, false);
      var doctorOptsHtml = buildBookingSelectOptions(BOOKING_DOCTORS, true);
      var timeOptsHtml = '<option value="" disabled selected>-- Pilih Jam --</option>' + buildBookingSelectOptions(BOOKING_TIMES, false);

      modalBackdrop.innerHTML =
        '<div class="booking-modal-dialog">' +
          '<div class="booking-modal-head">' +
            '<div>' +
              '<h2 class="booking-modal-title" id="global-booking-modal-title">Booking Janji Temu - Lily Clinic</h2>' +
              '<p class="booking-modal-subtitle">Isi data singkat di bawah ini agar tim admin kami bisa langsung mengonfirmasi jadwal dokter via WhatsApp.</p>' +
            '</div>' +
            '<button type="button" class="booking-modal-close" id="global-booking-close" aria-label="Tutup Form Booking">' +
              '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                '<line x1="18" y1="6" x2="6" y2="18"></line>' +
                '<line x1="6" y1="6" x2="18" y2="18"></line>' +
              '</svg>' +
            '</button>' +
          '</div>' +
          '<form id="gmodal-form" novalidate>' +
            '<div class="booking-form-row">' +
              '<div class="form-group">' +
                '<label for="gmodal-name" class="form-label">Nama Lengkap Pasien <span class="req">*</span></label>' +
                '<input type="text" id="gmodal-name" class="form-control" placeholder="Contoh: Siti Rahma" required>' +
                '<div class="form-error-msg" id="gmodal-name-error"></div>' +
              '</div>' +
              '<div class="form-group">' +
                '<label for="gmodal-phone" class="form-label">Nomor WhatsApp Pasien <span class="req">*</span></label>' +
                '<input type="tel" id="gmodal-phone" class="form-control" placeholder="Contoh: 0812-3456-7890" required>' +
                '<div class="form-error-msg" id="gmodal-phone-error"></div>' +
              '</div>' +
            '</div>' +
            '<div class="form-group">' +
              '<label for="gmodal-service" class="form-label">Pilih Layanan <span class="req">*</span></label>' +
              '<select id="gmodal-service" class="form-control" required>' + serviceOptsHtml + '</select>' +
              '<div class="form-error-msg" id="gmodal-service-error"></div>' +
            '</div>' +
            '<div class="form-group">' +
              '<label for="gmodal-doctor" class="form-label">Pilih Dokter <span class="req">*</span></label>' +
              '<select id="gmodal-doctor" class="form-control" required>' + doctorOptsHtml + '</select>' +
              '<div class="form-error-msg" id="gmodal-doctor-error"></div>' +
              '<p class="form-helper-note">Jadwal di atas adalah jadwal hari Senin. Beberapa dokter di Lily Clinic juga tersedia by appointment di luar jam praktek. Jika dokter yang dipilih tidak bertugas, admin akan tawarkan jadwal terdekat.</p>' +
            '</div>' +
            '<div class="booking-form-row">' +
              '<div class="form-group">' +
                '<label for="gmodal-date" class="form-label">Pilih Tanggal Kunjungan <span class="req">*</span></label>' +
                '<input type="date" id="gmodal-date" class="form-control" required>' +
                '<div class="form-error-msg" id="gmodal-date-error"></div>' +
              '</div>' +
              '<div class="form-group">' +
                '<label for="gmodal-time" class="form-label">Pilih Jam Kunjungan <span class="req">*</span></label>' +
                '<select id="gmodal-time" class="form-control" required>' + timeOptsHtml + '</select>' +
                '<div class="form-error-msg" id="gmodal-time-error"></div>' +
                '<div class="doctor-time-hint" id="gmodal-doctor-time-hint"></div>' +
              '</div>' +
            '</div>' +
            '<div class="form-group">' +
              '<label for="gmodal-notes" class="form-label">Keluhan / Catatan (opsional)</label>' +
              '<textarea id="gmodal-notes" class="form-control" placeholder="Ceritakan keluhan gigi kamu, contoh: Gigi ngilu 2 hari, mau scaling, dll"></textarea>' +
            '</div>' +
            '<button type="submit" class="btn btn-wa booking-submit-btn">' +
              OFFICIAL_WA_SVG +
              ' Kirim Booking via WhatsApp' +
            '</button>' +
            '<div class="booking-secondary-row">' +
              '<a href="https://wa.me/628886161770?text=Halo%20Lily%20Clinic%2C%20saya%20mau%20tanya%20dulu%20sebelum%20booking" target="_blank" rel="noopener noreferrer" class="btn btn-outline booking-secondary-btn">' +
                OFFICIAL_WA_SVG +
                ' Tanya via WhatsApp Dulu' +
              '</a>' +
            '</div>' +
            '<div class="booking-success-box" id="gmodal-success-box">' +
              'Terima kasih! Booking kamu sudah terkirim ke WhatsApp Lily Clinic. Admin akan segera membalas ya.' +
            '</div>' +
          '</form>' +
        '</div>';

      document.body.appendChild(modalBackdrop);
    }

    var backdropEl = document.getElementById('global-booking-modal');
    var closeBtn = document.getElementById('global-booking-close');
    var modalController = setupBookingFormInstance('gmodal');

    function openGlobalBooking(serviceSlugOrName, doctorName) {
      var mobileNav = document.querySelector('.mobile-nav');
      var toggleBtn = document.querySelector('.nav-toggle');
      if (mobileNav && mobileNav.classList.contains('open')) mobileNav.classList.remove('open');
      if (toggleBtn && toggleBtn.classList.contains('open')) toggleBtn.classList.remove('open');
      if (modalController) modalController.prefill(serviceSlugOrName, doctorName);
      backdropEl.classList.add('open');
      document.body.style.overflow = 'hidden';
      setTimeout(function () {
        var nameField = document.getElementById('gmodal-name');
        if (nameField) nameField.focus();
      }, 60);
    }

    function closeGlobalBooking() {
      backdropEl.classList.remove('open');
      document.body.style.overflow = '';
    }

    if (closeBtn) closeBtn.addEventListener('click', closeGlobalBooking);

    backdropEl.addEventListener('click', function (e) {
      if (e.target === backdropEl) closeGlobalBooking();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && backdropEl.classList.contains('open')) closeGlobalBooking();
    });

    document.addEventListener('click', function (e) {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var trigger = e.target.closest('[data-open-booking], a[href^="booking.html"]');
      if (!trigger || trigger.closest('#global-booking-modal')) return;

      var searchModal = document.getElementById('site-search-modal');
      if (searchModal && searchModal.classList.contains('open')) searchModal.classList.remove('open');

      e.preventDefault();
      var serviceAttr = trigger.getAttribute('data-booking-service') || '';
      var doctorAttr = trigger.getAttribute('data-doctor') || '';

      if (!serviceAttr) {
        var href = trigger.getAttribute('href') || '';
        if (href.indexOf('layanan=') !== -1) {
          serviceAttr = decodeURIComponent((href.split('layanan=')[1] || '').split('&')[0]);
        }
      }
      openGlobalBooking(serviceAttr, doctorAttr);
    });
  }

  function initBookingForm() {
    var form = document.getElementById('booking-form');
    if (!form) return;

    var modal = document.getElementById('booking-modal');
    var modalCloseBtn = document.getElementById('booking-modal-close');
    var urlParams = new URLSearchParams(window.location.search);
    var paramLayanan = urlParams.get('layanan') || '';
    var paramDokter = urlParams.get('dokter') || '';

    var pageController = setupBookingFormInstance('booking', {
      onSuccess: function () {
        if (modal) modal.classList.add('open');
      }
    });

    if (pageController && (paramLayanan || paramDokter)) {
      pageController.prefill(paramLayanan, paramDokter);
    }

    if (modal) {
      if (modalCloseBtn) {
        modalCloseBtn.addEventListener('click', function () {
          modal.classList.remove('open');
        });
      }
      modal.addEventListener('click', function (e) {
        if (e.target === modal) modal.classList.remove('open');
      });
    }
  }

  // ==========================================
  // 6. DOKTER SCHEDULE TOGGLE (dokter.html)
  // ==========================================
  function initDoctorScheduleToggles() {
    var scheduleBtns = document.querySelectorAll('[data-schedule-target]');
    if (scheduleBtns.length === 0) return;

    for (var i = 0; i < scheduleBtns.length; i++) {
      scheduleBtns[i].addEventListener('click', function () {
        var targetId = this.getAttribute('data-schedule-target');
        var panel = document.getElementById(targetId);
        if (!panel) return;
        var isOpen = panel.classList.contains('open');
        panel.classList.toggle('open', !isOpen);
        this.textContent = isOpen ? 'Lihat Jadwal' : 'Tutup Jadwal';
      });
    }
  }

  // ==========================================
  // 7. HEADER SEARCH MODAL & LIVE FILTER
  // ==========================================
  function initSearch() {
    var searchBtns = document.querySelectorAll('.nav-search-btn');
    if (searchBtns.length === 0) return;

    var searchIndex = [];
    var serviceKeywords = {
      'implant-gigi': 'implant tanam gigi titanium akar gigi hilang permanen',
      'kawat-gigi-orto': 'behel kawat ortodonti orto invisalign aligner merapikan gigi',
      'veneer': 'veneer putih estetik celah diastema senyum porselen',
      'operasi-gigi-bungsu': 'odontektomi bungsu impaksi miring bedah sakit rahang cabut gigi',
      'tambalan-estetik': 'tambal berlubang karies komposit sewarna gigi ngilu',
      'gigi-palsu': 'gigi tiruan lepasan valplast akrilik ompong',
      'crown-and-bridge': 'mahkota jaket crown bridge porselen zirconia patah',
      'perawatan-gusi': 'periodontik kuretase radang gusi berdarah bau mulut bengkak',
      'scaling-polishing': 'scaling polishing karang gigi plak ultrasonik poles noda kopi teh',
      'bleaching-pemutihan-gigi': 'bleaching pemutihan gigi whitening putih cerah instan',
      'perawatan-gigi-anak': 'anak pedodonti gigi susu balita ramah anak fluoride',
      'konsultasi-dokter-umum': 'dokter umum dwi aprilita konsultasi kesehatan keluarga demam batuk'
    };

    var keys = Object.keys(SERVICES_DATA);
    for (var i = 0; i < keys.length; i++) {
      var slug = keys[i];
      var svc = SERVICES_DATA[slug];
      searchIndex.push({
        title: svc.title,
        category: 'Layanan',
        desc: svc.desc,
        url: 'layanan-detail.html?layanan=' + encodeURIComponent(slug),
        keywords: svc.badge + ' ' + (serviceKeywords[slug] || '')
      });
    }

    var extraPages = [
      {
        title: 'Buat Janji / Booking Konsultasi',
        category: 'Booking',
        desc: 'Formulir reservasi pasien dan konfirmasi jadwal dokter via WhatsApp 0888-6161-770.',
        url: 'booking.html',
        keywords: 'booking janji temu reservasi jadwal daftar antri konsultasi'
      },
      {
        title: 'Jam Buka Operasional Klinik',
        category: 'Info Klinik',
        desc: 'Senin - Jumat 09.00 - 21.00 WIB, Sabtu 09.00 - 18.00 WIB, Minggu Tutup.',
        url: 'kontak.html',
        keywords: 'jam buka operasional tutup senin selasa rabu kamis jumat sabtu minggu malam'
      },
      {
        title: 'Alamat, Peta & Lokasi Lily Clinic',
        category: 'Kontak',
        desc: 'Ruko Citra Garden 2 Ext Blok BD 1 No 15, Pegadungan, Kalideres, Jakarta Barat 11830. Telp (021) 5441675.',
        url: 'kontak.html',
        keywords: 'alamat lokasi maps peta citra palem garden kalideres jakarta barat telepon parkir'
      },
      {
        title: 'Dokter Kami - Profil & Jadwal Praktek',
        category: 'Dokter',
        desc: 'drg. Lily Widjaja, drg. E. Widojati, drg. Mariska Slametiani, dan Dr. Dwi Aprilita siap melayani keluarga Anda.',
        url: 'dokter.html',
        keywords: 'dokter lily widjaja widojati mariska dwi aprilita jadwal praktek senin'
      },
      {
        title: 'Tentang Klinik & Fasilitas Medis',
        category: 'Profil',
        desc: 'Klinik Umum dan Gigi Citra Palem dengan peralatan modern, mikroskop dental, dan 4 pilar komitmen.',
        url: 'tentang.html#jadwal',
        keywords: 'tentang profil fasilitas gedung klinik pratama'
      },
      {
        title: 'Testimoni & Ulasan Pasien Google (4.9)',
        category: 'Ulasan',
        desc: 'Rating 4.9 bintang dari 89 ulasan Google. Pengalaman nyata pasien cabut gigi, behel, scaling, dan anak.',
        url: 'testimoni.html',
        keywords: 'testimoni ulasan review rating bintang google pengalaman pasien'
      },
      {
        title: 'Pertanyaan yang Sering Diajukan (FAQ)',
        category: 'FAQ',
        desc: 'Jawaban soal konsultasi awal, sakit saat cabut gigi, biaya scaling, pasien anak, dan lokasi parkir.',
        url: 'faq.html',
        keywords: 'faq tanya jawab harga biaya scaling sakit cabut parkir konsultasi'
      }
    ];

    for (var p = 0; p < extraPages.length; p++) {
      searchIndex.push(extraPages[p]);
    }

    var backdrop = document.createElement('div');
    backdrop.className = 'search-modal-backdrop';
    backdrop.id = 'site-search-modal';
    backdrop.setAttribute('role', 'dialog');
    backdrop.setAttribute('aria-modal', 'true');
    backdrop.setAttribute('aria-label', 'Pencarian Lily Clinic');

    backdrop.innerHTML =
      '<div class="search-modal-dialog">' +
        '<div class="search-modal-header">' +
          '<span class="search-modal-icon">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">' +
              '<circle cx="11" cy="11" r="8"></circle>' +
              '<line x1="21" y1="21" x2="16.65" y2="16.65"></line>' +
            '</svg>' +
          '</span>' +
          '<input type="search" id="site-search-input" class="search-modal-input" placeholder="Cari layanan gigi, jadwal, lokasi..." autocomplete="off">' +
          '<button type="button" class="search-modal-close" id="site-search-close" aria-label="Tutup Pencarian">' +
            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' +
              '<line x1="18" y1="6" x2="6" y2="18"></line>' +
              '<line x1="6" y1="6" x2="18" y2="18"></line>' +
            '</svg>' +
          '</button>' +
        '</div>' +
        '<div class="search-modal-suggestions" id="site-search-chips">' +
          '<button type="button" class="search-chip" data-query="Implant">Implant</button>' +
          '<button type="button" class="search-chip" data-query="Behel">Behel / Orto</button>' +
          '<button type="button" class="search-chip" data-query="Veneer">Veneer</button>' +
          '<button type="button" class="search-chip" data-query="Scaling">Scaling</button>' +
          '<button type="button" class="search-chip" data-query="Anak">Gigi Anak</button>' +
          '<button type="button" class="search-chip" data-query="Jam Buka">Jam Buka</button>' +
          '<button type="button" class="search-chip" data-query="Booking">Booking</button>' +
        '</div>' +
        '<div class="search-modal-results" id="site-search-results"></div>' +
      '</div>';

    document.body.appendChild(backdrop);

    var inputEl = document.getElementById('site-search-input');
    var closeBtn = document.getElementById('site-search-close');
    var resultsEl = document.getElementById('site-search-results');
    var chipsContainer = document.getElementById('site-search-chips');

    function renderResults(queryText) {
      var q = (queryText || '').trim().toLowerCase();
      resultsEl.innerHTML = '';

      var matches = [];
      for (var j = 0; j < searchIndex.length; j++) {
        var item = searchIndex[j];
        if (!q) {
          matches.push(item);
        } else {
          var haystack = (item.title + ' ' + item.category + ' ' + item.desc + ' ' + item.keywords).toLowerCase();
          if (haystack.indexOf(q) !== -1) matches.push(item);
        }
      }

      var limit = q ? matches.length : Math.min(matches.length, 6);
      if (limit === 0) {
        var emptyWrap = document.createElement('div');
        emptyWrap.className = 'search-empty-state';

        var emptyTitle = document.createElement('div');
        emptyTitle.className = 'search-empty-title';
        emptyTitle.textContent = 'Hasil tidak ditemukan untuk "' + queryText.trim() + '"';

        var emptyDesc = document.createElement('p');
        emptyDesc.className = 'search-empty-desc';
        emptyDesc.textContent = 'Coba kata kunci lain atau tanyakan langsung kepada tim admin kami via WhatsApp.';

        var waBtn = document.createElement('a');
        waBtn.href = 'https://wa.me/628886161770?text=' + encodeURIComponent('Halo Lily Clinic, saya mau tanya tentang ' + queryText.trim());
        waBtn.target = '_blank';
        waBtn.rel = 'noopener noreferrer';
        waBtn.className = 'btn btn-wa btn-sm';
        waBtn.innerHTML = OFFICIAL_WA_SVG + ' Tanya via WhatsApp';

        emptyWrap.appendChild(emptyTitle);
        emptyWrap.appendChild(emptyDesc);
        emptyWrap.appendChild(waBtn);
        resultsEl.appendChild(emptyWrap);
        return;
      }

      for (var k = 0; k < limit; k++) {
        var row = matches[k];
        var link = document.createElement('a');
        link.href = row.url;
        link.className = 'search-result-item';

        var topRow = document.createElement('div');
        topRow.className = 'search-result-top';

        var titleSpan = document.createElement('span');
        titleSpan.className = 'search-result-title';
        titleSpan.textContent = row.title;

        var badgeSpan = document.createElement('span');
        badgeSpan.className = 'search-result-badge';
        badgeSpan.textContent = row.category;

        topRow.appendChild(titleSpan);
        topRow.appendChild(badgeSpan);

        var descDiv = document.createElement('div');
        descDiv.className = 'search-result-desc';
        descDiv.textContent = row.desc;

        link.appendChild(topRow);
        link.appendChild(descDiv);
        resultsEl.appendChild(link);
      }
    }

    function openSearch() {
      var mobileNav = document.querySelector('.mobile-nav');
      var toggleBtn = document.querySelector('.nav-toggle');
      if (mobileNav && mobileNav.classList.contains('open')) mobileNav.classList.remove('open');
      if (toggleBtn && toggleBtn.classList.contains('open')) toggleBtn.classList.remove('open');
      backdrop.classList.add('open');
      renderResults(inputEl.value);
      setTimeout(function () {
        inputEl.focus();
      }, 60);
    }

    function closeSearch() {
      backdrop.classList.remove('open');
    }

    for (var s = 0; s < searchBtns.length; s++) {
      searchBtns[s].addEventListener('click', function (e) {
        e.preventDefault();
        openSearch();
      });
    }

    closeBtn.addEventListener('click', closeSearch);
    backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) closeSearch();
    });
    inputEl.addEventListener('input', function () {
      renderResults(inputEl.value);
    });
    inputEl.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        var firstResult = resultsEl.querySelector('.search-result-item');
        if (firstResult) window.location.href = firstResult.getAttribute('href');
      }
    });
    chipsContainer.addEventListener('click', function (e) {
      var chip = e.target.closest('.search-chip');
      if (!chip) return;
      inputEl.value = chip.getAttribute('data-query') || '';
      renderResults(inputEl.value);
      inputEl.focus();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && backdrop.classList.contains('open')) closeSearch();
    });
  }

  // ==========================================
  // 8. DESKTOP HERO CURSOR TILT + UNIFIED SCROLL CONTROLLER + STAGGER
  // ==========================================
  function initHeroDesktopTilt() {
    var heroSection = document.querySelector('.hero-split-section');
    var tiltEl = document.getElementById('hero-photo-tilt');
    if (!heroSection || !tiltEl) return;

    var idleTimer = null;
    var desktopQuery = window.matchMedia('(min-width: 992px) and (hover: hover)');

    function resetTilt() {
      tiltEl.style.transform = '';
    }

    heroSection.addEventListener('mousemove', function (e) {
      if (!desktopQuery.matches) return;
      var rect = heroSection.getBoundingClientRect();
      if (!rect.width || !rect.height) return;

      var nx = Math.max(-1, Math.min(1, ((e.clientX - rect.left) / rect.width) * 2 - 1));
      var ny = Math.max(-1, Math.min(1, ((e.clientY - rect.top) / rect.height) * 2 - 1));

      var rotY = nx * 4.5;
      var rotX = -ny * 3.2;
      var shiftX = nx * 9;
      var shiftY = ny * 5;

      tiltEl.style.transform =
        'perspective(1000px) rotateY(' + rotY.toFixed(2) + 'deg) rotateX(' + rotX.toFixed(2) + 'deg) ' +
        'translate3d(' + shiftX.toFixed(2) + 'px, ' + shiftY.toFixed(2) + 'px, 0)';

      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(resetTilt, 1600);
    });

    heroSection.addEventListener('mouseleave', function () {
      if (idleTimer) clearTimeout(idleTimer);
      resetTilt();
    });

    window.addEventListener('resize', function () {
      if (!desktopQuery.matches) {
        if (idleTimer) clearTimeout(idleTimer);
        resetTilt();
      }
    }, { passive: true });
  }

  function initStaggerIndices() {
    var grids = document.querySelectorAll('.services-grid, .craft-grid, .features-grid, .doctors-grid, .testimonial-grid');
    for (var g = 0; g < grids.length; g++) {
      var children = grids[g].children;
      for (var c = 0; c < children.length; c++) {
        children[c].style.setProperty('--stagger', String(c % 6));
      }
    }
  }

  function initUnifiedScrollController() {
    var navbar = document.querySelector('.site-navbar');
    var waBtn = document.querySelector('.floating-wa');
    var footer = document.querySelector('.site-footer');
    var parallaxEl = document.getElementById('hero-photo-parallax');
    var desktopParallaxQuery = window.matchMedia('(min-width: 992px)');

    var ticking = false;

    function runScrollUpdates() {
      ticking = false;
      var sy = window.scrollY || window.pageYOffset || 0;

      if (navbar) {
        navbar.classList.toggle('scrolled', sy > 20);
      }

      if (waBtn && footer) {
        var footerRect = footer.getBoundingClientRect();
        waBtn.classList.toggle('hide-near-footer', footerRect.top <= window.innerHeight - 12);
      }

      if (parallaxEl) {
        if (desktopParallaxQuery.matches) {
          var offset = Math.max(0, Math.min(sy * 0.12, 36));
          parallaxEl.style.transform = 'translate3d(0, ' + offset.toFixed(2) + 'px, 0)';
        } else {
          parallaxEl.style.transform = '';
        }
      }
    }

    function requestScrollTick() {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(runScrollUpdates);
      }
    }

    window.addEventListener('scroll', requestScrollTick, { passive: true });
    window.addEventListener('resize', requestScrollTick, { passive: true });
    runScrollUpdates();
  }

  // ==========================================
  // INITIALIZATION ON DOM READY
  // ==========================================
  document.addEventListener('DOMContentLoaded', function () {
    initNavbar();
    initHeroSlider();
    initHeroDesktopTilt();
    initStaggerIndices();
    initUnifiedScrollController();
    initFaqAccordion();
    initLayananDetail();
    initGlobalBookingModal();
    initBookingForm();
    initDoctorScheduleToggles();
    initSearch();
  });
})();
