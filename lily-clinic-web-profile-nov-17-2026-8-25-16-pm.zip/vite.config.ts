import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          layanan: path.resolve(__dirname, 'layanan.html'),
          'layanan-detail': path.resolve(__dirname, 'layanan-detail.html'),
          dokter: path.resolve(__dirname, 'dokter.html'),
          tentang: path.resolve(__dirname, 'tentang.html'),
          testimoni: path.resolve(__dirname, 'testimoni.html'),
          booking: path.resolve(__dirname, 'booking.html'),
          faq: path.resolve(__dirname, 'faq.html'),
          kontak: path.resolve(__dirname, 'kontak.html'),
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
